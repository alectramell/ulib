#!/bin/bash

clear

sensible-browser --new-window="https://www.facebook.com/messages/apollondma"

clear
