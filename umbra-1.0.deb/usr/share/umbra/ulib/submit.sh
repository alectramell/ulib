#!/bin/bash

clear

sensible-browser --new-window="https://m.facebook.com/messages/thread/215380691966805/?refid=17"

clear
