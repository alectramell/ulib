#!/bin/bash

clear

sensible-browser --new-window="https://www.facebook.com/apollondma"

clear
